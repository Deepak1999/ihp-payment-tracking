import React from 'react';
import '../Navbar/Navbar.css';

const Home = () => {
    return (
        <div className="container tab-content">
            <div id="home" className="tab-section">
                <h2>Welcome to IHP Payment Portal</h2>
            </div>
        </div>
    );
};

export default Home;
