
const ApiBaseUrl = 'https://api1.liveabuzz.com'

export default ApiBaseUrl;